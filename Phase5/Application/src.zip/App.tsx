import React, { useState, useEffect } from 'react';
import { Call, Volunteer, User as UserType } from './types';
import { Header } from './components/Header';
import { CallCard } from './components/CallCard';
import { NewCallModal } from './components/NewCallModal';
import { VolunteerModal } from './components/VolunteerModal';
import { SmartAssignModal } from './components/SmartAssignModal';
import { VolunteerManagement } from './components/VolunteerManagement';
import { ManagerDashboard } from './components/ManagerDashboard';
import { FunctionsDashboard } from './components/FunctionsDashboard';
import { ViewsDashboard } from './components/ViewsDashboard';
import { SystemAdminPanel } from './components/SystemAdminPanel';
import { TrainingManagement } from './components/TrainingManagement';
import { AvailabilityManagement } from './components/AvailabilityManagement';
import { AssignCallsDashboard } from './components/AssignCallsDashboard';
import { Auth } from './components/Auth';
import { Plus, ListFilter, Activity, History, Users, UserCircle, ShieldCheck, LogOut, CheckCircle2, Home, LayoutDashboard,  Settings2, Eye, Database, Pickaxe, MapPin, UserPlus, ClipboardList, BookOpen, Clock, Zap, Map } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [user, setUser] = useState<UserType | null>({
    id: '0',
    email: 'admin@domain.com',
    role: 'boss',
    volunteer_id: '0'
  });
  const [calls, setCalls] = useState<Call[]>([]);
  const [volunteers, setVolunteers] = useState<Volunteer[]>([]);
  const [volunteer, setVolunteer] = useState<Volunteer | null>(null);
  const [pendingManagers, setPendingManagers] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isVolunteerModalOpen, setIsVolunteerModalOpen] = useState(false);
  const [editingCall, setEditingCall] = useState<Call | null>(null);
  const [assigningCall, setAssigningCall] = useState<Call | null>(null);
  const [editingVolunteer, setEditingVolunteer] = useState<Volunteer | null>(null);
  const [filter, setFilter] = useState<'all' | 'open' | 'my' | 'volunteers' | 'pending' | 'home' | 'reports' | 'functions' | 'dashboard' | 'views' | 'infrastructure' | 'skills' | 'trainings' | 'availability' | 'assign_calls'>('home');
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState<{message: string, type: 'success'|'error'} | null>(null);

  const showNotification = (message: string, type: 'success'|'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 5000);
  };

  const isAdmin = user?.role === 'boss' || user?.role === 'manager';
  const currentVolunteerId = user?.volunteer_id;

  useEffect(() => {
    if (user) {
      fetchData();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchData = async () => {
    try {
      // אחזור נתוני הקריאות
      const callsRes = await fetch('/api/calls');
      if (callsRes.ok) {
        const callsData = await callsRes.json().catch(() => []);
        setCalls(callsData || []);
      }

      // אחזור רשימת כל המתנדבים
      const volunteersRes = await fetch('/api/volunteers');
      if (volunteersRes.ok) {
        const volunteersData = await volunteersRes.json().catch(() => []);
        setVolunteers(volunteersData || []);
      }

      // אחזור פרטי המתנדב הנוכחי (במידה וקיים) במקרה שלנו זה מנהל דמה אז נבלע את השגיאה
      if (user && user.volunteer_id) {
        try {
          const volunteerRes = await fetch(`/api/volunteers/${user.volunteer_id}`);
          if (volunteerRes.ok) {
            const text = await volunteerRes.text();
            if (text) {
              setVolunteer(JSON.parse(text));
            }
          }
        } catch (e) {
          // מתעלם אם לא מצא
        }
      }

      if (user?.role === 'boss' || user?.role === 'manager') {
        const pendingRes = await fetch('/api/admin/pending-managers');
        if (pendingRes.ok) {
          const pendingData = await pendingRes.json().catch(() => []);
          setPendingManagers(pendingData || []);
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };


  const handleApproveManager = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/approve-manager/${id}`, { method: 'POST' });
      if (res.ok) fetchData();
    } catch (error) {
      console.error('Error approving manager:', error);
    }
  };

  const handleCreateCall = async (data: any, forceDuplicate = false) => {
    try {
      if (editingCall) {
        const res = await fetch(`/api/calls/${editingCall.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        if (res.ok) {
          setIsModalOpen(false);
          setEditingCall(null);
          await fetchData();
          return null;
        } else {
          const err = await res.json();
          showNotification(err.error || 'Failed to update call', 'error');
          return err.error;
        }
      } else {
        const payload = { ...data, force_duplicate: forceDuplicate };
        const res = await fetch('/api/calls', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          setIsModalOpen(false);
          await fetchData();
          showNotification('הקריאה נוצרה בהצלחה!');
          return null;
        } else {
          const err = await res.json();
          if (res.status === 409 && err.error === 'duplicate') {
            return { isDuplicate: true, message: err.message };
          }
          showNotification(err.error || 'Failed to create call', 'error');
          return err.error;
        }
      }
    } catch (error) {
      console.error('Error saving call:', error);
      showNotification('Network error saving call', 'error');
      return 'Network error';
    }
  };

  const handleTakeCall = async (id: string) => {
    try {
      const res = await fetch(`/api/calls/${id}/take`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ volunteerId: user?.volunteer_id })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error('Error taking call:', error);
    }
  };

  const handleCompleteCall = async (id: string) => {
    try {
      const res = await fetch(`/api/calls/${id}/complete`, {
        method: 'POST'
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error('Error completing call:', error);
    }
  };

  const handleDeleteCall = async (id: string) => {
    try {
      const res = await fetch(`/api/calls/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error('Error deleting call:', error);
    }
  };

  const handleEditCall = (call: Call) => {
    setEditingCall(call);
    setIsModalOpen(true);
  };

  const handleSmartAssign = (call: Call) => {
    setAssigningCall(call);
  };

  const handleExecuteAssign = async (callId: string, volunteerId: string) => {
    try {
      const res = await fetch(`/api/calls/${callId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ volunteerId })
      });
      if (res.ok) {
        await fetchData();
        setAssigningCall(null);
      }
    } catch (error) {
      console.error('Error assigning call:', error);
    }
  };

  const handleDeleteVolunteer = async (volunteerId: string) => {
    try {
      const res = await fetch(`/api/volunteers/${volunteerId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        showNotification('המתנדב נמחק בהצלחה');
        fetchData();
      }
    } catch (err) {
      showNotification('שגיאה במחיקת המתנדב', 'error');
    }
  };

  const handleSaveVolunteer = async (data: any) => {
    try {
      // Trim string fields to avoid trailing spaces breaking things or creating silent bugs
      const cleanedData = {
        ...data,
        email: typeof data.email === 'string' ? data.email.trim() : data.email,
        phone: typeof data.phone === 'string' ? data.phone.trim() : data.phone,
        first_name: typeof data.first_name === 'string' ? data.first_name.trim() : data.first_name,
        last_name: typeof data.last_name === 'string' ? data.last_name.trim() : data.last_name,
      };

      if (editingVolunteer) {
        const res = await fetch(`/api/volunteers/${editingVolunteer.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(cleanedData)
        });
        if (res.ok) {
          setIsVolunteerModalOpen(false);
          setEditingVolunteer(null);
          fetchData();
          showNotification('המתנדב עודכן בהצלחה!');
          return null;
        } else {
          const err = await res.json();
          const errorMsg = (err.error || 'שגיאה בעדכון מתנדב') + (err.details ? ': ' + err.details : '');
          showNotification(errorMsg, 'error');
          return errorMsg;
        }
      } else {
        const res = await fetch('/api/volunteers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(cleanedData)
        });
        if (res.ok) {
          setIsVolunteerModalOpen(false);
          fetchData();
          showNotification('המתנדב נוצר בהצלחה! סיסמת ההתחברות הראשונית שלו היא: 123456');
          return null;
        } else {
          const err = await res.json();
          const errorMsg = (err.error || 'שגיאה ביצירת מתנדב') + (err.details ? ': ' + err.details : '');
          showNotification(errorMsg, 'error');
          return errorMsg;
        }
      }
    } catch (error) {
      console.error('Error saving volunteer:', error);
      const networkErr = 'שגיאת תקשורת';
      showNotification(networkErr, 'error');
      return networkErr;
    }
  };

  const handleEditVolunteer = (v: Volunteer) => {
    setEditingVolunteer(v);
    setIsVolunteerModalOpen(true);
  };

  const handlePromoteVolunteer = async (v: Volunteer) => {
    try {
      const res = await fetch(`/api/admin/promote-to-manager/${v.id}`, { method: 'POST' });
      if (res.ok) {
        showNotification('המתנדב הוגדר כמנהל בהצלחה!');
        fetchData();
      } else {
        const err = await res.json();
        showNotification(err.error || 'שגיאה בהגדרת כמנהל', 'error');
      }
    } catch (error) {
      console.error('Error promoting volunteer:', error);
      showNotification('שגיאת תקשורת', 'error');
    }
  };

  const groupCallsByMonth = (callsToGroup: Call[]) => {
    const groups: { [key: string]: Call[] } = {};
    callsToGroup.forEach(call => {
      const date = new Date(call.created_at);
      const monthYear = date.toLocaleDateString('he-IL', { month: 'long', year: 'numeric' });
      if (!groups[monthYear]) groups[monthYear] = [];
      groups[monthYear].push(call);
    });
    return groups;
  };

  const filteredCalls = calls.filter(call => {
    if (filter === 'home') return false;
    if (filter === 'open') return call.status === 'open';
    if (filter === 'my') {
      return isAdmin ? call.status === 'completed' : call.volunteer_id === user?.volunteer_id;
    }
    return true;
  });


  return (
    <div className="min-h-screen bg-slate-50 font-sans pb-24 relative">
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className={`fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-2xl shadow-xl font-bold flex items-center gap-3 ${
              notification.type === 'error' ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white'
            }`}
          >
            {notification.type === 'error' ? <span className="text-xl">!</span> : <CheckCircle2 size={24} />}
            {notification.message}
          </motion.div>
        )}
      </AnimatePresence>

      <Header volunteer={volunteer} />

      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
          <div>
            <h2 className="text-3xl font-black text-slate-900">לוח קריאות</h2>
            <p className="text-slate-500 font-medium mt-1">צפה ונהל קריאות סיוע בזמן אמת</p>
          </div>

          <div className="flex flex-wrap gap-3 w-full md:w-auto">
            {isAdmin && (
              filter === 'volunteers' ? (
                <button
                  onClick={() => {
                    setEditingVolunteer(null);
                    setIsVolunteerModalOpen(true);
                  }}
                  className="flex-1 md:flex-none bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-100"
                >
                  <Plus size={20} />
                  מתנדב חדש
                </button>
              ) : (
                <button
                  onClick={() => {
                    setEditingCall(null);
                    setIsModalOpen(true);
                  }}
                  className="flex-1 md:flex-none bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-100"
                >
                  <Plus size={20} />
                  קריאה חדשה
                </button>
              )
            )}
            

            <button
              onClick={() => {
                setEditingVolunteer(volunteer);
                setIsVolunteerModalOpen(true);
              }}
              className="flex-1 md:flex-none bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold px-6 py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-sm"
            >
              <UserCircle size={20} />
              הפרופיל שלי
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-8 bg-white p-1.5 rounded-2xl border border-slate-200 w-fit">
          {isAdmin && (
            <button
              onClick={() => setFilter('home')}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${filter === 'home' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              <Home size={16} />
              תפריט ראשי
            </button>
          )}
          <button
            onClick={() => setFilter('all')}
            className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${filter === 'all' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Activity size={16} />
            {isAdmin ? 'ניהול קריאות' : 'כל הקריאות'}
          </button>
          <button
            onClick={() => setFilter('open')}
            className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${filter === 'open' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <ListFilter size={16} />
            פתוחות
          </button>
          <button
            onClick={() => setFilter('my')}
            className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${filter === 'my' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <History size={16} />
            {isAdmin ? 'היסטוריה כללית' : 'ההיסטוריה שלי'}
          </button>
          {isAdmin && (
            <>
              <button
                onClick={() => setFilter('volunteers')}
                className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${filter === 'volunteers' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
              >
                <Users size={16} />
                אגף מתנדבים
              </button>
              {pendingManagers.length > 0 && (
                <button
                  onClick={() => setFilter('pending')}
                  className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${filter === 'pending' ? 'bg-amber-600 text-white shadow-md' : 'text-amber-600 hover:bg-amber-50'}`}
                >
                  <ShieldCheck size={16} />
                  בקשות ניהול ({pendingManagers.length})
                </button>
              )}
            </>
          )}
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : filter === 'dashboard' && isAdmin ? (
          <ManagerDashboard />
        ) : filter === 'home' && isAdmin ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 py-6">
            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => setFilter('all')} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-blue-500">
              <div className="bg-blue-50 p-6 rounded-3xl text-blue-600 mb-4 group-hover:bg-blue-600 group-hover:text-white transition-all"><Activity size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">ניהול קריאות</h3>
              <p className="text-slate-500 text-sm">צפייה וניהול קריאות</p>
            </motion.button>
            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => { setEditingCall(null); setIsModalOpen(true); }} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-blue-500">
              <div className="bg-blue-50 p-6 rounded-3xl text-blue-600 mb-4 group-hover:bg-blue-600 group-hover:text-white transition-all"><Plus size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">קריאה חדשה</h3>
              <p className="text-slate-500 text-sm">פתיחת קריאה</p>
            </motion.button>
            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => setFilter('volunteers')} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-emerald-500">
              <div className="bg-emerald-50 p-6 rounded-3xl text-emerald-600 mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-all"><Users size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">ניהול מתנדבים</h3>
              <p className="text-slate-500 text-sm">רשימה ופעולות</p>
            </motion.button>
            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => { setEditingVolunteer(null); setIsVolunteerModalOpen(true); }} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-emerald-500">
              <div className="bg-emerald-50 p-6 rounded-3xl text-emerald-600 mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-all"><UserPlus size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">מתנדב חדש</h3>
              <p className="text-slate-500 text-sm">הוספת מתנדב</p>
            </motion.button>
            
            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => setFilter('trainings')} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-orange-500">
              <div className="bg-orange-50 p-6 rounded-3xl text-orange-600 mb-4 group-hover:bg-orange-600 group-hover:text-white transition-all"><BookOpen size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">ניהול הכשרות</h3>
              <p className="text-slate-500 text-sm">קורסים והסמכות</p>
            </motion.button>
            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => setFilter('availability')} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-teal-500">
              <div className="bg-teal-50 p-6 rounded-3xl text-teal-600 mb-4 group-hover:bg-teal-600 group-hover:text-white transition-all"><Clock size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">זמינות מתנדבים</h3>
              <p className="text-slate-500 text-sm">לוז וזמנים</p>
            </motion.button>
            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => setFilter('assign_calls')} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-indigo-500">
              <div className="bg-indigo-50 p-6 rounded-3xl text-indigo-600 mb-4 group-hover:bg-indigo-600 group-hover:text-white transition-all"><MapPin size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">שיבוץ מתנדבים</h3>
              <p className="text-slate-500 text-sm">התאמת מתנדב לקריאה</p>
            </motion.button>

            <motion.button whileHover={{ scale: 1.02, y: -5 }} onClick={() => setFilter('functions')} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center group transition-all hover:border-red-500">
              <div className="bg-red-50 p-6 rounded-3xl text-red-600 mb-4 group-hover:bg-red-600 group-hover:text-white transition-all"><Zap size={40} /></div>
              <h3 className="text-xl font-black text-slate-900 mb-2">אשף פעולות חכמות</h3>
              <p className="text-slate-500 text-sm">כלים אוטומטיים ופעולות תשתית</p>
            </motion.button>
          </div>
        ) : filter === 'volunteers' ? (
          <VolunteerManagement 
            volunteers={volunteers} 
            onEdit={handleEditVolunteer} 
            onPromote={handlePromoteVolunteer}
            onDelete={handleDeleteVolunteer}
            currentRole={user?.role}
          />
        ) : filter === 'functions' ? (
          <FunctionsDashboard />
        ) : filter === 'infrastructure' || filter === 'skills' ? (
          <SystemAdminPanel />
        ) : filter === 'trainings' ? (
          <TrainingManagement />
        ) : filter === 'availability' ? (
          <AvailabilityManagement />
        ) : filter === 'assign_calls' ? (
          <AssignCallsDashboard calls={calls} volunteers={volunteers} onAssign={handleExecuteAssign} />
        ) : filter === 'pending' ? (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-slate-800 mb-6">בקשות הצטרפות לניהול</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingManagers.map(manager => (
                <div key={manager.id} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex justify-between items-center">
                  <div>
                    <h4 className="font-bold text-slate-900">{manager.name}</h4>
                    <p className="text-sm text-slate-500">{manager.email}</p>
                  </div>
                  <button
                    onClick={() => handleApproveManager(manager.id)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2"
                  >
                    <CheckCircle2 size={16} />
                    אשר מנהל
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : filteredCalls.length > 0 ? (
          filter === 'my' || (isAdmin && filter === 'all') ? (
            <div className="space-y-12">
              {Object.entries(groupCallsByMonth(
                filter === 'all' ? filteredCalls.filter(c => c.status === 'completed') : filteredCalls
              )).map(([month, monthCalls]) => (
                <div key={month}>
                  <div className="flex items-center gap-4 mb-6">
                    <h3 className="text-xl font-bold text-slate-800">{month}</h3>
                    <div className="h-px bg-slate-200 flex-1"></div>
                    <span className="text-xs font-bold bg-slate-100 text-slate-500 px-3 py-1 rounded-full">
                      {monthCalls.length} קריאות
                    </span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {monthCalls.map(call => (
                      <CallCard
                        key={call.id}
                        call={call}
                        onTake={handleTakeCall}
                        onComplete={handleCompleteCall}
                        onDelete={handleDeleteCall}
                        onEdit={handleEditCall}
                        isCurrentVolunteer={call.volunteer_id === currentVolunteerId}
                        isAdmin={isAdmin}
                        onSmartAssign={handleSmartAssign}
                      />
                    ))}
                  </div>
                </div>
              ))}
              {isAdmin && filter === 'all' && filteredCalls.filter(c => c.status === 'in-progress').length > 0 && (
                <div>
                  <div className="flex items-center gap-4 mb-6">
                    <h3 className="text-xl font-bold text-slate-800">קריאות בטיפול</h3>
                    <div className="h-px bg-slate-200 flex-1"></div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredCalls.filter(c => c.status === 'in-progress').map(call => (
                      <CallCard
                        key={call.id}
                        call={call}
                        onTake={handleTakeCall}
                        onComplete={handleCompleteCall}
                        onDelete={handleDeleteCall}
                        onEdit={handleEditCall}
                        isCurrentVolunteer={call.volunteer_id === currentVolunteerId}
                        isAdmin={isAdmin}
                        onSmartAssign={handleSmartAssign}
                      />
                    ))}
                  </div>
                </div>
              )}
              {isAdmin && filter === 'all' && filteredCalls.filter(c => c.status === 'open').length > 0 && (
                <div className="mt-12">
                  <div className="flex items-center gap-4 mb-6">
                    <h3 className="text-xl font-bold text-slate-800">קריאות פתוחות</h3>
                    <div className="h-px bg-slate-200 flex-1"></div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredCalls.filter(c => c.status === 'open').map(call => (
                      <CallCard
                        key={call.id}
                        call={call}
                        onTake={handleTakeCall}
                        onComplete={handleCompleteCall}
                        onDelete={handleDeleteCall}
                        onEdit={handleEditCall}
                        isCurrentVolunteer={call.volunteer_id === currentVolunteerId}
                        isAdmin={isAdmin}
                        onSmartAssign={handleSmartAssign}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCalls.map(call => (
                <CallCard
                  key={call.id}
                  call={call}
                  onTake={handleTakeCall}
                  onComplete={handleCompleteCall}
                  onDelete={handleDeleteCall}
                  onEdit={handleEditCall}
                  isCurrentVolunteer={call.volunteer_id === currentVolunteerId}
                  isAdmin={isAdmin}
                  onSmartAssign={handleSmartAssign}
                />
              ))}
            </div>
          )
        ) : (
          <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 py-20 flex flex-col items-center justify-center text-center px-6">
            <div className="bg-slate-50 p-6 rounded-full mb-4">
              <Activity size={48} className="text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-800">אין קריאות להצגה</h3>
            <p className="text-slate-500 mt-2 max-w-xs">כרגע אין קריאות העונות לסינון שבחרת. נסה לשנות את הסינון או להמתין לקריאות חדשות.</p>
          </div>
        )}
      </main>

      <NewCallModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingCall(null);
        }}
        onSubmit={handleCreateCall}
        initialData={editingCall}
      />

      <VolunteerModal
        isOpen={isVolunteerModalOpen}
        onClose={() => {
          setIsVolunteerModalOpen(false);
          setEditingVolunteer(null);
        }}
        onSubmit={handleSaveVolunteer}
        initialData={editingVolunteer}
      />

      <SmartAssignModal
        isOpen={!!assigningCall}
        mode="smart"
        onClose={() => setAssigningCall(null)}
        call={assigningCall}
        volunteers={volunteers}
        onAssign={handleExecuteAssign}
      />

      <footer className="max-w-5xl mx-auto px-4 py-12 border-t border-slate-200 mt-20">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 opacity-50">
            <ShieldCheck size={20} />
            <span className="text-sm font-bold">מערכת ניהול מתנדבים ידידים - גרסה 1.0</span>
          </div>
          <div className="text-slate-400 text-xs font-medium">
            נבנה באהבה למען הקהילה
          </div>
        </div>
      </footer>
    </div>
  );
}
