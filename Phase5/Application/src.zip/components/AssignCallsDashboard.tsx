import React, { useState } from 'react';
import { Call, Volunteer } from '../types';
import { MapPin, AlertCircle, CheckCircle2, User, UserCheck } from 'lucide-react';
import { SmartAssignModal } from './SmartAssignModal';

interface AssignCallsDashboardProps {
  calls: Call[];
  volunteers: Volunteer[];
  onAssign: (callId: string, volunteerId: string) => Promise<void>;
}

export const AssignCallsDashboard: React.FC<AssignCallsDashboardProps> = ({ calls, volunteers, onAssign }) => {
  const [assigningCall, setAssigningCall] = useState<Call | null>(null);
  const [assignMode, setAssignMode] = useState<'manual'|'smart'>('manual');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  
  // Show calls that are strictly open and have no volunteer assigned
  const openCalls = calls.filter(c => c.status === 'open' && !c.volunteer_id);

  const handleBestMatch = (call: Call) => {
    setAssignMode('smart');
    setAssigningCall(call);
  };

  const handleManualAssign = (call: Call) => {
    setAssignMode('manual');
    setAssigningCall(call);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-black text-slate-800">שיבוץ מתנדבים לקריאות</h2>
          <p className="text-slate-500">קריאות ממתינות לשיבוץ והתאמת ציוד ומיומנויות</p>
        </div>
      </div>

      {successMessage && (
        <div className="bg-emerald-50 text-emerald-700 p-4 rounded-xl border border-emerald-200 flex items-center gap-2 font-bold mb-6">
          <CheckCircle2 size={20} />
          {successMessage}
        </div>
      )}

      {openCalls.length === 0 ? (
        <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 py-16 flex flex-col items-center justify-center text-center">
          <CheckCircle2 size={48} className="text-emerald-400 mb-4" />
          <h3 className="text-xl font-bold text-slate-800">אין קריאות פתוחות</h3>
          <p className="text-slate-500">כל הקריאות מטופלות או שאין קריאות חדשות במערכת.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {openCalls.map(call => (
            <div key={call.id} className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col md:flex-row gap-6 justify-between items-start md:items-center shadow-sm">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <span className={`px-2 py-1 rounded-md text-xs font-bold ${call.priority_level && call.priority_level >= 4 ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'}`}>
                    דחיפות {call.priority_level || 1}
                  </span>
                  <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-md text-xs font-bold">
                    {call.type}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">ID: {call.id}</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-1">{call.title}</h3>
                <div className="flex items-center gap-4 text-sm text-slate-500">
                  <div className="flex items-center gap-1">
                    <MapPin size={14} />
                    {call.location}
                  </div>
                  {(call.caller_name || call.caller_phone) && (
                    <div className="flex items-center gap-1">
                      <User size={14} />
                      {call.caller_name} - {call.caller_phone}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex gap-3 w-full md:w-auto">
                <button
                  onClick={() => handleManualAssign(call)}
                  className="flex-1 md:flex-none border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 text-slate-700 px-4 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all"
                >
                  <User size={16} />
                  שיבוץ ידני
                </button>
                <button
                  onClick={() => handleBestMatch(call)}
                  className="flex-1 md:flex-none bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-md shadow-indigo-200"
                >
                  <UserCheck size={16} />
                  שבץ מתנדב מתאים
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {assigningCall && (
        <SmartAssignModal
          isOpen={true}
          mode={assignMode}
          onClose={() => setAssigningCall(null)}
          call={assigningCall}
          volunteers={volunteers}
          onAssign={async (callId, vId) => {
            await onAssign(callId, vId);
            const volunteerName = volunteers.find(v => v.id === vId)?.name;
            setSuccessMessage(`שובץ בהצלחה: ${volunteerName} לקריאה ${assigningCall.title}`);
            setTimeout(() => setSuccessMessage(null), 3000);
            setAssigningCall(null);
          }}
        />
      )}
    </div>
  );
};
