import React, { useState, useEffect } from 'react';
import { Clock, Plus, Edit2, Trash2 } from 'lucide-react';

export const AvailabilityManagement = () => {
  const [availabilities, setAvailabilities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/availabilities')
      .then(res => res.json())
      .then(data => {
        setAvailabilities(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching availabilities:', err);
        setLoading(false);
      });
  }, []);

  const dayNames = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-black text-slate-800">ניהול זמינות מתנדבים</h2>
          <p className="text-slate-500">ניהול חלונות זמן מועדפים לפעילות</p>
        </div>
        <button className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2">
          <Plus size={16} />
          הוסף זמינות
        </button>
      </div>

      <div className="grid border border-slate-200 rounded-2xl overflow-hidden bg-white">
        <div className="grid grid-cols-6 gap-4 bg-slate-50 p-4 font-bold text-slate-700 text-sm border-b border-slate-200">
          <div>שם מתנדב</div>
          <div>יום בשבוע</div>
          <div>שעת הפעלה</div>
          <div>שעת סיום</div>
          <div>אזור מועדף</div>
          <div className="text-center">פעולות</div>
        </div>
        
        {loading ? (
          <div className="p-8 text-center text-slate-500">טוען נתונים...</div>
        ) : availabilities.length === 0 ? (
          <div className="p-8 text-center text-slate-500">אין נתוני זמינות במערכת.</div>
        ) : (
          availabilities.map(a => (
            <div key={a.id} className="grid grid-cols-6 gap-4 p-4 border-b border-slate-100 items-center last:border-0 hover:bg-slate-50 transition-colors">
              <div className="font-bold text-slate-900">{a.volunteer_name || 'לא ידוע'}</div>
              <div className="text-slate-600">{dayNames[a.day_of_week] || a.day_of_week}</div>
              <div className="text-slate-600 font-mono flex items-center gap-1"><Clock size={12}/>{a.start_time}</div>
              <div className="text-slate-600 font-mono flex items-center gap-1"><Clock size={12}/>{a.end_time}</div>
              <div className="text-slate-600">
                <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded-md text-xs font-bold">{a.preferred_region || 'כללי'}</span>
              </div>
              <div className="flex justify-center gap-2">
                <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                  <Edit2 size={16} />
                </button>
                <button className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
