import React from 'react';
import { Call } from '../types';
import { MapPin, Clock, User, CheckCircle, Navigation, Trash2, Pencil, Map, Wand2 } from 'lucide-react';
import { motion } from 'motion/react';

interface CallCardProps {
  call: Call;
  onTake: (id: string) => void;
  onComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (call: Call) => void;
  isCurrentVolunteer: boolean;
  isAdmin?: boolean;
  onSmartAssign?: (call: Call) => void;
}

export const CallCard: React.FC<CallCardProps> = ({ call, onTake, onComplete, onDelete, onEdit, isCurrentVolunteer, isAdmin, onSmartAssign }) => {
  const [isConfirmingDelete, setIsConfirmingDelete] = React.useState(false);

  const statusColors = {
    'open': 'bg-blue-100 text-blue-700 border-blue-200',
    'in-progress': 'bg-orange-100 text-orange-700 border-orange-200',
    'completed': 'bg-green-100 text-green-700 border-green-200'
  };

  const statusLabels = {
    'open': 'פתוח',
    'in-progress': 'בטיפול',
    'completed': 'טופל'
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow"
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="flex gap-2">
            <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${statusColors[call.status]}`}>
              {statusLabels[call.status]}
            </span>
            {call.priority_level && (
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${
                call.priority_level >= 4 ? 'bg-red-100 text-red-700 border-red-200' :
                call.priority_level === 3 ? 'bg-orange-100 text-orange-700 border-orange-200' :
                'bg-slate-100 text-slate-700 border-slate-200'
              }`}>
                דחיפות: {call.priority_level}
              </span>
            )}
          </div>
          <h3 className="text-xl font-bold mt-3 text-slate-800">{call.title}</h3>
        </div>
        <div className="bg-slate-100 p-2 rounded-xl">
          <span className="text-sm font-medium text-slate-600">{call.type}</span>
        </div>
      </div>
      
      {call.image_url && call.image_url.trim() !== '' && call.image_url !== 'null' && (
        <div className="w-full h-32 mb-4 rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
          <img src={call.image_url} alt="תמונה מצורפת" className="w-full h-full object-cover" />
        </div>
      )}

      <div className="space-y-3 mb-6">
        <div className="flex items-start text-slate-600 gap-2">
          <MapPin size={18} className="text-slate-400 mt-0.5 shrink-0" />
          <div className="flex flex-col">
            <span className="text-sm">{call.location}</span>
            {call.latitude && call.longitude && (
              <div className="flex gap-3 mt-1">
                <a 
                  href={`https://waze.com/ul?ll=${call.latitude},${call.longitude}&navigate=yes`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1"
                >
                  <Navigation size={12} /> ניווט ב-Waze
                </a>
                <a 
                  href={`https://maps.google.com/?q=${call.latitude},${call.longitude}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-emerald-600 hover:text-emerald-800 font-medium flex items-center gap-1"
                >
                  <Map size={12} /> מפות Google
                </a>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center text-slate-600 gap-2">
          <Clock size={18} className="text-slate-400" />
          <span className="text-sm">
            <span dir="ltr">
              {call.call_date 
                ? `${new Date(call.call_date).toLocaleDateString('he-IL')} ${call.call_time ? call.call_time.substring(0, 5) : ''}`
                : call.created_at 
                  ? `${new Date(call.created_at.split(' ')[0]).toLocaleDateString('he-IL')} ${call.created_at.split(' ')[1]?.substring(0, 5) || ''}`
                  : ''}
            </span>
          </span>
        </div>
        {call.volunteer_name && (
          <div className="flex items-center text-slate-600 gap-2">
            <User size={18} className="text-slate-400" />
            <span className="text-sm">מתנדב: {call.volunteer_name}</span>
          </div>
        )}
      </div>

      {(call.caller_name || call.caller_phone || call.caller_special_features) && (
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 mb-6 space-y-2">
          <h4 className="text-xs font-bold text-slate-700">פרטי פונה</h4>
          <div className="flex flex-col gap-1">
            {call.caller_name && <span className="text-sm text-slate-600">שם: {call.caller_name}</span>}
            {call.caller_phone && <span className="text-sm text-slate-600">טלפון: {call.caller_phone}</span>}
            {call.caller_special_features && <span className="text-sm text-red-600 font-medium mt-1">מאפיינים: {call.caller_special_features}</span>}
          </div>
        </div>
      )}

      <div className="flex gap-2">
        {call.status === 'open' && (
          <>
            {isConfirmingDelete ? (
              <div className="flex-1 flex gap-2">
                <button
                  onClick={() => {
                    onDelete(call.id);
                    setIsConfirmingDelete(false);
                  }}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl transition-colors text-sm"
                >
                  בטוח? מחק
                </button>
                <button
                  onClick={() => setIsConfirmingDelete(false)}
                  className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-3 rounded-xl transition-colors text-sm"
                >
                  ביטול
                </button>
              </div>
            ) : (
              <div className="flex flex-col w-full gap-2">
                <div className="flex gap-2">
                  <button
                    onClick={() => onTake(call.id)}
                    className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors border border-slate-200"
                  >
                    <Navigation size={18} />
                    אני יוצא
                  </button>
                  {isAdmin && onSmartAssign && (
                    <button
                      onClick={() => onSmartAssign(call)}
                      className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-blue-500/20"
                    >
                      <Wand2 size={18} />
                      שיבוץ חכם
                    </button>
                  )}
                </div>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsConfirmingDelete(true)}
                      className="flex-1 bg-slate-50 hover:bg-red-50 text-slate-500 hover:text-red-600 p-2 rounded-xl transition-all border border-slate-100 hover:border-red-100 flex justify-center items-center gap-1 text-sm font-medium"
                    >
                      <Trash2 size={16} /> מחק
                    </button>
                    <button
                      onClick={() => onEdit(call)}
                      className="flex-1 bg-slate-50 hover:bg-blue-50 text-slate-500 hover:text-blue-600 p-2 rounded-xl transition-all border border-slate-100 hover:border-blue-100 flex justify-center items-center gap-1 text-sm font-medium"
                    >
                      <Pencil size={16} /> ערוך
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}
        {(call.status === 'in-progress' || call.status === 'open') && (isCurrentVolunteer || isAdmin) && (
          <button
            onClick={() => onComplete(call.id)}
            className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <CheckCircle size={18} />
            סגור קריאה
          </button>
        )}
      </div>
    </motion.div>
  );
};
