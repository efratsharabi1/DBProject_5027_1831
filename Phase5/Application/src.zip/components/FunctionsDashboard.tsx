import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings2, RefreshCw, CheckCircle2, AlertCircle, Users, Map } from 'lucide-react';

export const FunctionsDashboard: React.FC = () => {
  const [activeAction, setActiveAction] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<Record<string, any> | null>(null);

  const runFunction = async (actionId: string) => {
    setActiveAction(actionId);
    setIsProcessing(true);
    setResult(null);

    try {
      if (actionId === 'find-unassigned') {
        const res = await fetch('/api/calls');
        const calls = await res.json();

        const unassigned = calls.filter(
          (c: any) => c.status !== 'closed' && c.status !== 'Closed' && !c.volunteer_id
        );

        setResult({
          message: unassigned.length > 0
            ? 'נמצאו קריאות שטרם שובץ אליהן מתנדב'
            : 'לא נמצאו קריאות פתוחות ללא מתנדבים',
          data: unassigned.map((c: any) => ({
            title: c.title,
            location: c.location || '',
            urgency: c.priority_level || '1'
          }))
        });
      }

      if (actionId === 'find-top-volunteer') {
        const res = await fetch('/api/stats/top-volunteer');

        if (res.ok) {
          const topVol = await res.json();

          if (topVol && topVol.name) {
            setResult({
              message: 'נמצא המתנדב המצטיין במערכת!',
              data: [
                { title: 'שם המתנדב', value: topVol.name },
                { title: 'כמות קריאות שסגר בהצלחה', value: topVol.call_count }
              ]
            });
          } else {
            setResult({
              message: 'לא נמצאו נתונים מספקים על מתנדב מצטיין',
              data: []
            });
          }
        }
      }
    } catch (e) {
      setResult({ message: 'שגיאה במהלך הפעולה', data: [] });
    } finally {
      setIsProcessing(false);
    }
  };

  const functionsList = [
    {
      id: 'find-unassigned',
      title: 'מציאת קריאות ללא מתנדבים',
      desc: 'שליפה ורשימה של קריאות הממתינות למתנדב',
      icon: <Map size={48} />,
      colorClasses: 'bg-blue-50 text-blue-600 group-hover:bg-blue-600'
    },
    {
      id: 'find-top-volunteer',
      title: 'מציאת המתנדב המצטיין',
      desc: 'איתור המתנדב שטיפל בהכי הרבה קריאות בהצלחה',
      icon: <Users size={48} />,
      colorClasses: 'bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600'
    }
  ];

  return (
    <div className="py-10 max-w-5xl mx-auto space-y-10">
      <div className="flex items-center justify-center gap-4 text-center">
        <div className="bg-sky-100 p-3 rounded-2xl text-sky-600">
          <Settings2 size={32} />
        </div>
        <div>
          <h2 className="text-3xl font-black text-slate-900">אשף פעולות חכמות</h2>
          <p className="text-slate-500 font-medium">כלים אוטומטיים ופעולות תשתית</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {functionsList.map((fn) => (
          <motion.button
            key={fn.id}
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => runFunction(fn.id)}
            disabled={isProcessing}
            className={`bg-white p-8 rounded-3xl border ${
              activeAction === fn.id ? 'border-sky-500 ring-2 ring-sky-50' : 'border-slate-200'
            } shadow-sm flex flex-col items-center text-center group transition-all disabled:opacity-70`}
          >
            <div className={`${fn.colorClasses} p-6 rounded-3xl mb-5 group-hover:text-white transition-colors`}>
              {fn.icon}
            </div>
            <h3 className="text-2xl font-black text-slate-900 mb-2">{fn.title}</h3>
            <p className="text-slate-500 text-sm">{fn.desc}</p>
          </motion.button>
        ))}
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden min-h-[300px]">
        {isProcessing ? (
          <div className="h-full flex flex-col items-center justify-center py-24 space-y-6">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-slate-100 rounded-full"></div>
              <div className="w-16 h-16 border-4 border-sky-500 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
              <RefreshCw size={24} className="text-sky-500 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
            </div>
            <div className="text-center">
              <h4 className="text-xl font-bold text-slate-800">מבצע עיבוד נתונים...</h4>
              <p className="text-slate-500 mt-2 text-sm">אנא המתן מספר שניות</p>
            </div>
          </div>
        ) : result ? (
          <AnimatePresence mode="wait">
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8"
            >
              <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 mb-8 flex items-start gap-4">
                <div className="bg-white p-2 rounded-xl shadow-sm text-emerald-600 shrink-0">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-emerald-900 text-lg mb-1">הפעולה הסתיימה בהצלחה</h4>
                  <p className="text-emerald-700 leading-relaxed">{result.message}</p>
                </div>
              </div>

              {result.data && result.data.length > 0 ? (
                <div className="overflow-x-auto rounded-xl border border-slate-200">
                  <table className="w-full text-right bg-white">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        {Object.keys(result.data[0]).map((key) => (
                          <th key={key} className="p-4 font-bold text-slate-600">
                            {key === 'title' ? 'פרטים / שם' :
                             key === 'location' ? 'מיקום' :
                             key === 'urgency' ? 'דחיפות' :
                             key === 'value' ? 'ערך' :
                             key}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {result.data.map((row: any, i: number) => (
                        <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                          {Object.entries(row).map(([k, v]) => (
                            <td key={k} className="p-4 text-slate-700">
                              {v as React.ReactNode}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-8 text-center text-slate-500">
                  לא הוחזרו נתונים להצגה.
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="h-full flex flex-col items-center justify-center py-24 text-center px-6">
            <div className="bg-slate-50 p-6 rounded-full mb-4">
              <AlertCircle size={48} className="text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-800">בחר פונקציה להפעלה</h3>
            <p className="text-slate-500 mt-2 max-w-sm">
              המערכת מוכנה להרצת הפעולות מול מסד הנתונים
            </p>
          </div>
        )}
      </div>
    </div>
  );
};