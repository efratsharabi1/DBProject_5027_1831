import React from 'react';
import { User, ShieldCheck } from 'lucide-react';
import { Volunteer } from '../types';

interface HeaderProps {
  volunteer: Volunteer | null;
}

export const Header: React.FC<HeaderProps> = ({ volunteer }) => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
      <div className="max-w-5xl mx-auto px-4 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3 text-blue-600">
          <ShieldCheck size={32} />
          <span className="text-xl font-black hidden sm:inline">ידידים</span>
        </div>

        {volunteer && (
          <div className="flex items-center gap-4 bg-slate-50 px-4 py-2 rounded-2xl border border-slate-100">
            <div className="text-left">
              <p className="text-sm font-black text-slate-800 leading-none">ברוך הבא, {volunteer.name}</p>
            </div>
            <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-100">
              <User size={20} className="text-slate-600" />
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
