import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Activity, Users, CheckCircle2, AlertCircle, MapPin, TrendingUp, Briefcase } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';

export const ManagerDashboard: React.FC = () => {
  const [overview, setOverview] = useState<any>(null);
  const [callsByDate, setCallsByDate] = useState<any[]>([]);
  const [topLocations, setTopLocations] = useState<any[]>([]);
  const [topVolunteer, setTopVolunteer] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [overviewRes, callsRes, locationsRes, topVolRes] = await Promise.all([
          fetch('/api/stats/overview'),
          fetch('/api/stats/call-by-date'),
          fetch('/api/stats/top-location'),
          fetch('/api/stats/top-volunteer')
        ]);
        
        setOverview(await overviewRes.json());
        setCallsByDate(await callsRes.json());
        setTopLocations(await locationsRes.json());
        setTopVolunteer(await topVolRes.json());
      } catch (err) {
        console.error('Error fetching stats:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading || !overview) {
    return (
      <div className="flex justify-center py-20">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const statCards = [
    { title: 'סה"כ קריאות', value: overview.totalCalls, icon: <Activity size={24} />, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100' },
    { title: 'קריאות פתוחות', value: overview.openCalls, icon: <AlertCircle size={24} />, color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-100' },
    { title: 'קריאות שהושלמו', value: overview.completedCalls, icon: <CheckCircle2 size={24} />, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100' },
    { title: 'סה"כ מתנדבים', value: overview.totalVolunteers, icon: <Users size={24} />, color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-100' },
    { title: 'מתנדב מצטיין', value: topVolunteer ? topVolunteer.name : 'אין', subtitle: topVolunteer ? `${topVolunteer.call_count} קריאות` : '', icon: <Briefcase size={24} />, color: 'text-yellow-600', bg: 'bg-yellow-50', border: 'border-yellow-100' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-blue-100 p-3 rounded-xl text-blue-600">
          <TrendingUp size={28} />
        </div>
        <div>
          <h2 className="text-2xl font-black text-slate-800">דשבורד מנהלים</h2>
          <p className="text-slate-500">תמונת מצב עדכנית של פעילות הארגון</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {statCards.map((stat, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`bg-white p-6 rounded-2xl border ${stat.border} shadow-sm flex items-center gap-4`}
          >
            <div className={`${stat.bg} ${stat.color} p-4 rounded-xl`}>
              {stat.icon}
            </div>
            <div>
              <p className="text-sm font-bold text-slate-500">{stat.title}</p>
              <h3 className="text-2xl font-black text-slate-800">{stat.value}</h3>
              {stat.subtitle && <p className="text-xs font-bold text-yellow-600 mt-1">{stat.subtitle}</p>}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm"
        >
          <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <Activity size={20} className="text-blue-500" />
            קריאות ב-14 הימים האחרונים
          </h3>
          <div className="h-72 w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%" style={{ minWidth: 0, minHeight: 0 }}>
              <LineChart data={callsByDate} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickMargin={10} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  labelStyle={{ fontWeight: 'bold', color: '#334155' }}
                />
                <Line type="monotone" dataKey="count" name="קריאות" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm"
        >
          <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <MapPin size={20} className="text-orange-500" />
            הערים הפעילות ביותר
          </h3>
          <div className="h-72 w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%" style={{ minWidth: 0, minHeight: 0 }}>
              <BarChart data={topLocations} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                <XAxis type="number" stroke="#94a3b8" fontSize={12} />
                <YAxis dataKey="location" type="category" stroke="#94a3b8" fontSize={12} width={80} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="count" name="קריאות" fill="#f97316" radius={[0, 4, 4, 0]} barSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
