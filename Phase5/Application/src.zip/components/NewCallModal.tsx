import React, { useState } from 'react';
import { X, PlusCircle, Pencil, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NewCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<any> | void;
  initialData?: any;
}

export const NewCallModal: React.FC<NewCallModalProps> = ({ isOpen, onClose, onSubmit, initialData }) => {
  const [formData, setFormData] = useState({
    title: '',
    location: '',
    latitude: undefined as number | undefined,
    longitude: undefined as number | undefined,
    type: 'התנעת רכב (כבלים)',
    description: '',
    call_date: new Date().toISOString().split('T')[0],
    call_time: new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }),
    priority_level: 1,
    image_url: '',
    caller_name: '',
    caller_phone: '',
    caller_special_features: ''
  });

  React.useEffect(() => {
    if (initialData) {
      setFormData({
        title: initialData.title || '',
        location: initialData.location || '',
        latitude: initialData.latitude,
        longitude: initialData.longitude,
        type: initialData.type || 'התנעת רכב (כבלים)',
        description: initialData.description || '',
        call_date: initialData.call_date || new Date().toISOString().split('T')[0],
        call_time: initialData.call_time || new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }),
        priority_level: initialData.priority_level || 1,
        image_url: initialData.image_url || '',
        caller_name: initialData.caller_name || '',
        caller_phone: initialData.caller_phone || '',
        caller_special_features: initialData.caller_special_features || ''
      });
    } else {
      setFormData({ 
        title: '', location: '', latitude: undefined, longitude: undefined, type: 'התנעת רכב (כבלים)', description: '',
        call_date: new Date().toISOString().split('T')[0], call_time: new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }), 
        priority_level: 1, image_url: '', caller_name: '', caller_phone: '', caller_special_features: '' 
      });
    }
  }, [initialData, isOpen]);

  const [isValidating, setIsValidating] = useState(false);
  const [addressError, setAddressError] = useState<string | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      setAddressError('הדפדפן שלך אינו תומך בשירותי מיקום.');
      return;
    }

    setIsLocating(true);
    setAddressError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setFormData(prev => ({
          ...prev,
          latitude,
          longitude,
          location: prev.location || `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`
        }));
        setIsLocating(false);
      },
      (error) => {
        setIsLocating(false);
        setAddressError('לא ניתן לאתר את המיקום שלך. אנא ודא ששירותי המיקום מופעלים.');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const validateAddress = async (address: string) => {
    if (formData.latitude && formData.longitude) {
      return true; // Skip validation if we have exact coordinates
    }
    setAddressError(null);
    return true; // Always allow address to prevent API blocks
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl"
        >
          <div className="p-6 border-bottom border-slate-100 flex justify-between items-center bg-slate-50">
            <h2 className="text-xl font-black text-slate-800">
              {initialData ? 'עריכת קריאה' : 'פתיחת קריאה חדשה'}
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
              <X size={24} />
            </button>
          </div>

          <form className="p-6 space-y-4" onSubmit={async (e) => {
            e.preventDefault();
            setIsValidating(true);
            setAddressError(null);

            const [isAddressValid] = await Promise.all([
              validateAddress(formData.location)
            ]);

            setIsValidating(false);

            if (isAddressValid) {
              const res = await onSubmit({ ...formData, title: formData.type }, false);
              
              if (res && res.isDuplicate) {
                setDuplicateWarning(res.message);
                return;
              }

              if (!res) {
                setDuplicateWarning(null);
                setFormData({ 
                  title: '', location: '', latitude: undefined, longitude: undefined, type: 'התנעת רכב (כבלים)', description: '',
                  call_date: new Date().toISOString().split('T')[0], call_time: new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }), 
                  priority_level: 1, image_url: '', caller_name: '', caller_phone: '', caller_special_features: '' 
                });
              }
            }
          }}>
          
            {duplicateWarning && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col gap-3 mb-4">
                <div className="flex items-start gap-2">
                  <div className="text-amber-500 mt-0.5"><span className="font-bold text-lg">⚠️</span></div>
                  <div>
                    <h4 className="font-bold text-amber-800">התראת כפילות</h4>
                    <p className="text-sm text-amber-700">{duplicateWarning}</p>
                  </div>
                </div>
                <div className="flex justify-end gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setDuplicateWarning(null)}
                    className="px-4 py-2 bg-white text-slate-700 border border-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50 transition-colors"
                  >
                    ביטול
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await onSubmit({ ...formData, title: formData.type }, true);
                      if (!res) {
                        setDuplicateWarning(null);
                        setFormData({ 
                          title: '', location: '', latitude: undefined, longitude: undefined, type: 'התנעת רכב (כבלים)', description: '',
                          call_date: new Date().toISOString().split('T')[0], call_time: new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }), 
                          priority_level: 1, image_url: '', caller_name: '', caller_phone: '', caller_special_features: '' 
                        });
                      }
                    }}
                    className="px-4 py-2 bg-amber-600 text-white rounded-lg text-sm font-medium hover:bg-amber-700 transition-colors"
                  >
                    כן, דווח בכל זאת
                  </button>
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">מיקום</label>
              <div className="flex gap-2">
                <input
                  required
                  type="text"
                  value={formData.location}
                  onChange={(e) => {
                    setFormData({ ...formData, location: e.target.value });
                    if (addressError) setAddressError(null);
                  }}
                  placeholder="כתובת או נקודת ציון (למשל: כביש 6, ק'מ 100)"
                  className={`flex-1 px-4 py-3 rounded-xl border ${addressError ? 'border-red-500 bg-red-50' : 'border-slate-200'} focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all`}
                />
                <button
                  type="button"
                  onClick={handleGetLocation}
                  disabled={isLocating}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 p-3 rounded-xl transition-colors flex items-center justify-center"
                  title="השתמש במיקום הנוכחי שלי"
                >
                  {isLocating ? (
                    <div className="w-5 h-5 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <MapPin size={20} />
                  )}
                </button>
              </div>
              {formData.latitude && formData.longitude && (
                <p className="text-xs text-emerald-600 font-medium mt-1">
                  ✓ נשמרו נתוני מיקום מדויקים (GPS)
                </p>
              )}
              {addressError && (
                <p className="text-red-500 text-xs font-bold mt-1">{addressError}</p>
              )}
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <h3 className="text-sm font-black text-slate-800">פרטי פונה (חובה)</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">שם פונה <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={formData.caller_name}
                    onChange={(e) => setFormData({ ...formData, caller_name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">טלפון <span className="text-red-500">*</span></label>
                  <input
                    type="tel"
                    required
                    value={formData.caller_phone}
                    onChange={(e) => setFormData({ ...formData, caller_phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">מאפיינים מיוחדים</label>
                <input
                  type="text"
                  value={formData.caller_special_features}
                  onChange={(e) => setFormData({ ...formData, caller_special_features: e.target.value })}
                  placeholder="למשל: אישה בהריון, נכה, קשיש..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">רמת דחיפות (1-5)</label>
                <input
                  type="number"
                  min="1"
                  max="5"
                  value={formData.priority_level}
                  onChange={(e) => setFormData({ ...formData, priority_level: parseInt(e.target.value) || 1 })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">סוג סיוע</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all appearance-none bg-white"
                >
                  <option value="פתיחת רכב נעול">פתיחת רכב נעול (כולל חילוץ ילדים)</option>
                  <option value="התנעת רכב (כבלים)">התנעת רכב (כבלים)</option>
                  <option value="החלפת גלגל">החלפת גלגל</option>
                  <option value="חילוצים מיוחדים">חילוצים מיוחדים (בוץ, חול וכו')</option>
                  <option value="סיוע טכני בסיסי">סיוע טכני בסיסי (מים/דלק)</option>
                  <option value="עזרה בבית">עזרה בבית (סיוע טכני בסיסי)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">תמונה (אופציונלי - קישור לתמונה)</label>
              <input
                type="url"
                value={formData.image_url}
                onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                placeholder="https://example.com/image.jpg"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">תיאור (אופציונלי)</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                placeholder="אנא תאר את הבעיה בפירוט..."
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={isValidating}
              className={`w-full ${isValidating ? 'bg-slate-400' : 'bg-blue-600 hover:bg-blue-700'} text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-200 mt-4`}
            >
              {isValidating ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  {initialData ? <Pencil size={20} /> : <PlusCircle size={20} />}
                  {initialData ? 'עדכן קריאה' : 'שלח קריאה למוקד'}
                </>
              )}
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
