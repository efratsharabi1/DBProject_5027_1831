import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Call, Volunteer } from '../types';
import { X, Wand2, MapPin, User, CheckCircle2, Star } from 'lucide-react';

interface SmartAssignModalProps {
  isOpen: boolean;
  onClose: () => void;
  call: Call | null;
  onAssign: (callId: string, volunteerId: string) => Promise<void>;
  volunteers: Volunteer[];
  mode: 'manual' | 'smart';
}

export const SmartAssignModal: React.FC<SmartAssignModalProps> = ({ isOpen, onClose, call, onAssign, volunteers, mode }) => {
  const [isProcessing, setIsProcessing] = useState(true);
  const [matches, setMatches] = useState<any[]>([]);

  useEffect(() => {
    if (isOpen && call) {
      setIsProcessing(mode === 'smart');
      
      setTimeout(() => {
        const available = volunteers.filter(v => v.is_active !== 0);
        
        let allVolunteers = available.map(v => {
          let score = 0;
          let reason = '';
          
          if (mode === 'smart') {
            // Simulated score calculation based on the user's PL/pgSQL logic:
            
            // 1. Skill match
            let matchingSkillsCount = 0;
            if (call.type.includes('רכב') && v.has_equipment) matchingSkillsCount += 1;
            score += (matchingSkillsCount * 15);
            
            // 2. Equipment score
            if (v.has_equipment) {
              score += 20;
            }
            
            // 3. Availability score
            if (v.availability_status && v.availability_status.toLowerCase() === 'available') {
              score += 20;
            } else if (v.is_active) {
              score += 10;
            }
            
            // 4. Distance score (simplified distance calculation)
            if ((v as any).latitude && (v as any).longitude && call.latitude && call.longitude) {
              const dx = (v as any).latitude - call.latitude;
              const dy = (v as any).longitude - call.longitude;
              const distance = Math.sqrt(dx*dx + dy*dy);
              
              if (distance < 0.02) {
                score += 30;
              } else if (distance < 0.05) {
                score += 20;
              } else {
                score += 10;
              }
            } else if (v.residence && call.location && v.residence === call.location) {
              score += 25; // fallback string match
            }
            
            reason = `ציון התאמה: ${score}`;
          } else {
            reason = v.role === 'manager' || v.role === 'boss' ? "מנהל מערכת" : "מתנדב פעיל";
          }
          
          return {
            volunteer: v,
            score: score,
            reason: reason
          };
        });
        
        if (mode === 'smart') {
          allVolunteers.sort((a, b) => b.score - a.score);
        }
        
        setMatches(allVolunteers);
        setIsProcessing(false);
      }, mode === 'smart' ? 1500 : 0);
    }
  }, [isOpen, call, volunteers, mode]);

  if (!isOpen || !call) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-[32px] shadow-2xl w-full max-w-2xl flex flex-col max-h-[90vh]"
        >
          <div className={`p-6 flex items-center justify-between rounded-t-[32px] ${mode === 'smart' ? 'bg-gradient-to-r from-indigo-600 to-purple-600' : 'bg-gradient-to-r from-blue-600 to-sky-600'}`}>
            <div className="flex items-center gap-3 text-white">
              <div className="bg-white/20 p-2 rounded-xl">
                {mode === 'smart' ? <Wand2 size={24} /> : <User size={24} />}
              </div>
              <div>
                <h2 className="text-xl font-bold">{mode === 'smart' ? 'שיבוץ מתנדב חכם' : 'שיבוץ מתנדב ידני'}</h2>
                <p className="text-white/80 text-sm">{call.title}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors">
              <X size={24} />
            </button>
          </div>

          <div className="p-6 overflow-y-auto flex-1">
            {isProcessing ? (
              <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 border-4 border-slate-100 rounded-full relative">
                  <div className={`w-16 h-16 border-4 border-t-transparent rounded-full animate-spin absolute -top-1 -left-1 ${mode === 'smart' ? 'border-indigo-600' : 'border-blue-600'}`}></div>
                  {mode === 'smart' ? (
                    <Wand2 size={24} className="text-indigo-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
                  ) : (
                    <User size={24} className="text-blue-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  )}
                </div>
                <h3 className="text-xl font-bold text-slate-800">מחשב התאמות...</h3>
                <p className="text-slate-500 text-sm">האלגוריתם סורק את המתנדבים הזמינים לפי מיקום ומיומנות לטובת הקריאה.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <h3 className="font-bold text-slate-800 mb-4 px-2">
                  רשימת מתנדבים {mode === 'smart' ? 'מומלצים' : 'פעילים'} ({matches.length})
                </h3>
                {matches.map((m, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    key={m.volunteer.id} 
                    className={`border border-slate-200 rounded-2xl p-4 flex items-center justify-between transition-colors bg-white hover:bg-slate-50`}
                  >
                    <div className="flex items-center gap-4">
                      {m.volunteer.photo_url ? (
                        <img src={m.volunteer.photo_url} alt={m.volunteer.name} className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm" />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 shadow-sm border-2 border-white">
                          <User size={24} />
                        </div>
                      )}
                      <div>
                        <h4 className="font-bold text-slate-800 flex items-center gap-2">
                          {m.volunteer.name}
                          {mode === 'smart' && idx === 0 && (
                            <span className="bg-amber-100 text-amber-700 text-xs px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                              <Star size={10} className="fill-amber-500 text-amber-500" /> המלצת המערכת
                            </span>
                          )}
                        </h4>
                        <p className={`text-xs flex items-center gap-1 mt-1 font-medium ${mode === 'smart' ? 'text-indigo-600' : 'text-slate-500'}`}>
                          {mode === 'smart' ? <Wand2 size={12} /> : <MapPin size={12} />} {m.reason}
                        </p>
                      </div>
                    </div>
                    <div>
                      <button 
                        onClick={() => onAssign(call.id, m.volunteer.id)}
                        className={`text-white font-bold px-4 py-2 rounded-xl text-sm transition-colors shadow-sm ${mode === 'smart' ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-200'}`}
                      >
                        {mode === 'smart' ? 'שבץ מתנדב' : 'בחר ושבץ'}
                      </button>
                    </div>
                  </motion.div>
                ))}
                
                {matches.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    לא נמצאו מתנדבים מתאימים או זמינים לשיבוץ.
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

