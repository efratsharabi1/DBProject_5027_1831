import React, { useState, useEffect } from 'react';
import { Database, Plus, Edit2, Trash2 } from 'lucide-react';

const tables = [
  { id: 'c_types', name: 'סוגי קריאות', fields: ['name'] },
  { id: 'statuses', name: 'סטטוסים', fields: ['label'] },
  { id: 'categories', name: 'קטגוריות מיומנויות', fields: ['name'] },
  { id: 'callers', name: 'פונים', fields: ['name', 'phone_number', 'special_features'] },
  { id: 'locations', name: 'מיקומים', fields: ['address', 'latitude', 'longitude', 'location_notes'] },
  { id: 'skills', name: 'מיומנויות', fields: ['name', 'description', 'difficulty_level', 'requires_certificate', 'category_id'] }
];

export const SystemAdminPanel: React.FC = () => {
  const [activeTable, setActiveTable] = useState(tables[0]);
  const [data, setData] = useState<any[]>([]);
  const [formData, setFormData] = useState<any>({});
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ text: string, type: 'success' | 'error' } | null>(null);

  const showMsg = (text: string, type: 'success' | 'error' = 'success') => {
    setMsg({ text, type });
    setTimeout(() => setMsg(null), 3000);
  };

  const fetchData = async () => {
    try {
      const res = await fetch(`/api/sys/${activeTable.id}`);
      if (res.ok) {
        const json = await res.json();
        setData(json);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchData();
    setFormData({});
    setIsEditing(null);
  }, [activeTable]);

  const handleEdit = (item: any) => {
    setIsEditing(item.id);
    setFormData({ ...item });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id: string) => {
    const confirmDelete = window.confirm('האם אתה בטוח שברצונך למחוק רשומה זו?');
    if(!confirmDelete) return;
    try {
      const res = await fetch(`/api/sys/${activeTable.id}/${id}`, { method: 'DELETE' });
      if (res.ok) {
        showMsg('רשומה נמחקה בהצלחה', 'success');
        fetchData();
      } else {
        showMsg('שגיאה במחיקה (יתכן ויש תלויות לרשומה זו)', 'error');
      }
    } catch (err) {
      showMsg('שגיאה במחיקה', 'error');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isEditing) {
        const res = await fetch(`/api/sys/${activeTable.id}/${isEditing}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        if (res.ok) {
          showMsg('רשומה עודכנה בהצלחה', 'success');
          fetchData();
        } else {
           showMsg('שגיאה בעדכון', 'error');
        }
      } else {
        const res = await fetch(`/api/sys/${activeTable.id}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        if (res.ok) {
          showMsg('רשומה חדשה נוספה בהצלחה', 'success');
          fetchData();
        } else {
           showMsg('שגיאה בהוספה', 'error');
        }
      }
      setFormData({});
      setIsEditing(null);
    } catch (err) {
      showMsg('שגיאה בשמירה', 'error');
    }
  };

  return (
    <div className="py-10 max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8">
        <h2 className="text-2xl font-black text-slate-800 mb-6 flex items-center gap-2">
          <Database size={24} className="text-blue-600" /> סיסטם: ניהול ישויות מערכת (CRUD חופשי)
        </h2>

        {msg && (
          <div className={`p-4 mb-6 rounded-xl font-bold transition-all ${msg.type === 'success' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
            {msg.text}
          </div>
        )}

        <div className="flex gap-2 p-2 bg-slate-100 rounded-2xl mb-8 overflow-x-auto whitespace-nowrap">
          {tables.map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTable(t)}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${activeTable.id === t.id ? 'bg-white shadow-sm text-blue-600 border border-slate-200' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-200'}`}
            >
              {t.name}
            </button>
          ))}
        </div>

        <form onSubmit={handleSave} className="bg-slate-50 p-6 rounded-2xl mb-8 border border-slate-100">
          <h3 className="font-bold text-slate-700 mb-4 flex items-center gap-2">
             {isEditing ? <Edit2 size={16}/> : <Plus size={16}/>}
             {isEditing ? `עריכת רשומה בטבלת ${activeTable.name}` : `הוספת רשומה אל ${activeTable.name}`}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeTable.fields.map(field => (
              <div key={field}>
                <label className="block text-sm font-bold text-slate-600 mb-1">{field}</label>
                <input
                  type={field.includes('level') || field.includes('tude') || field.includes('certificate') ? 'number' : 'text'}
                  step={field.includes('tude') ? '0.000001' : '1'}
                  value={formData[field] || ''}
                  onChange={e => setFormData({ ...formData, [field]: e.target.type === 'number' ? Number(e.target.value) : e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none bg-white font-mono text-sm leading-relaxed"
                  required={field !== 'description' && field !== 'special_features' && field !== 'location_notes' && field !== 'category_id'}
                />
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-end gap-3">
            {isEditing && (
              <button
                type="button"
                onClick={() => { setIsEditing(null); setFormData({}); }}
                className="px-4 py-2 rounded-xl font-bold text-slate-600 bg-slate-200 hover:bg-slate-300 transition"
              >
                ביטול
              </button>
            )}
            <button
              type="submit"
              className="px-6 py-2 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 transition shadow-sm flex items-center gap-2"
            >
              {isEditing ? 'עדכן רשומה' : 'הוסף רשומה'}
            </button>
          </div>
        </form>

        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold">
                <th className="p-4 rounded-tr-xl w-24">מזהה</th>
                {activeTable.fields.map(f => (
                  <th key={f} className="p-4 text-slate-600">{f}</th>
                ))}
                <th className="p-4 rounded-tl-xl text-left w-24">פעולות</th>
              </tr>
            </thead>
            <tbody>
              {data.length === 0 ? (
                <tr>
                  <td colSpan={activeTable.fields.length + 2} className="p-6 text-center text-slate-500">
                    אין נתונים בטבלה זו
                  </td>
                </tr>
              ) : (
                data.map(item => (
                  <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                    <td className="p-4 text-xs font-mono text-slate-400" title={item.id}>...{String(item.id).substring(0, 5)}</td>
                    {activeTable.fields.map(f => (
                      <td key={f} className="p-4 text-slate-800 font-medium">{item[f]}</td>
                    ))}
                    <td className="p-4 text-left">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => handleEdit(item)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition" title="ערוך">
                          <Edit2 size={16} />
                        </button>
                        <button onClick={() => handleDelete(item.id)} className="p-2 text-rose-600 hover:bg-rose-100 rounded-lg transition" title="מחק">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
