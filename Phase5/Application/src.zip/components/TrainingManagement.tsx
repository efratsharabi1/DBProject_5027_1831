import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, CalendarDays, Users } from 'lucide-react';
import { NewTrainingModal } from './NewTrainingModal';

export const TrainingManagement = () => {
  const [trainings, setTrainings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [editingTraining, setEditingTraining] = useState<any | null>(null);
  const loadTrainings = () => {
    setLoading(true);
    fetch('/api/trainings')
      .then(res => res.json())
      .then(data => {
        setTrainings(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching trainings:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    loadTrainings();
  }, []);

  const handleDeleteTraining = async (id: string) => {
  if (!confirm('האם למחוק את ההכשרה?')) return;

  try {
    const res = await fetch(`/api/trainings/${id}`, {
      method: 'DELETE'
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(err.error || 'אירעה שגיאה במחיקת ההכשרה');
      return;
    }

    loadTrainings();
  } catch (err) {
    console.error(err);
    alert('אירעה שגיאה במחיקת ההכשרה');
  }
};

const handleSaveTraining = async (data: any) => {
  try {
    const url = editingTraining ? `/api/trainings/${editingTraining.id}` : '/api/trainings';
    const method = editingTraining ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(err.error || 'אירעה שגיאה בשמירת ההכשרה');
      return;
    }

    setIsModalOpen(false);
    setEditingTraining(null);
    loadTrainings();
  } catch (err) {
    console.error(err);
    alert('אירעה שגיאה בשמירת ההכשרה');
  }
};
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-black text-slate-800">ניהול הכשרות</h2>
          <p className="text-slate-500">ניהול קורסים, סדנאות והסמכות למתנדבים</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2"
        >
          <Plus size={16} />
          הכשרה חדשה
        </button>
      </div>

      <div className="grid border border-slate-200 rounded-2xl overflow-hidden bg-white">
        <div className="grid grid-cols-12 gap-4 bg-slate-50 p-4 font-bold text-slate-700 text-sm border-b border-slate-200">
          <div className="col-span-3">שם הכשרה</div>
          <div className="col-span-4">תיאור</div>
          <div className="col-span-1 text-center">משך (שעות)</div>
          <div className="col-span-2 text-center">משתתפים</div>
          <div className="col-span-2 text-center">פעולות</div>
        </div>
        
        {loading ? (
          <div className="p-8 text-center text-slate-500">טוען נתונים...</div>
        ) : trainings.length === 0 ? (
          <div className="p-8 text-center text-slate-500">אין הכשרות קיימות במערכת. לחץ על "הכשרה חדשה" כדי להוסיף.</div>
        ) : (
          trainings.map(t => (
            <div key={t.id} className="grid grid-cols-12 gap-4 p-4 border-b border-slate-100 items-center last:border-0 hover:bg-slate-50 transition-colors">
              <div className="col-span-3 font-bold text-slate-900">{t.name}</div>
              <div className="col-span-4 text-slate-600 text-sm">{t.description}</div>
              <div className="col-span-1 text-center text-slate-600 font-mono">{t.duration_hours || '-'}</div>
              <div className="col-span-2 text-center">
                <span className={`px-2 py-1 rounded-lg text-xs font-bold w-fit mx-auto flex items-center gap-1 ${(t.current_participants || 0) >= (t.max_participant || 999) ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'}`}>
                  <Users size={12} />
                  {t.current_participants || 0}/{t.max_participant || '-'}
                </span>
              </div>
              <div className="col-span-2 flex justify-center gap-2">
                <button
  onClick={() => {
    setEditingTraining(t);
    setIsModalOpen(true);
  }}
  className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
>
  <Edit2 size={16} />
</button>

<button
  onClick={() => handleDeleteTraining(t.id)}
  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
>
  <Trash2 size={16} />
</button>
              </div>
            </div>
          ))
        )}
      </div>

      

      <NewTrainingModal 
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTraining(null);
        }}
        onSave={handleSaveTraining}
        initialData={editingTraining}
      />
    </div>
  );
};
