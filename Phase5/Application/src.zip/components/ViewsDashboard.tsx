import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Layers, MapPin, AlertCircle, Eye, PhoneOff } from 'lucide-react';

export const ViewsDashboard: React.FC = () => {
  const [activeView, setActiveView] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const viewsList = [
    { id: 'volunteer_activity_view', title: 'volunteer_activity_view', icon: <Layers size={24} />, color: 'blue' },
    { id: 'caller_call_location_view', title: 'caller_call_location_view', icon: <MapPin size={24} />, color: 'emerald' },
    { id: 'calls_by_urgency', title: 'מספר קריאות לפי רמת דחיפות', icon: <AlertCircle size={24} />, color: 'orange' },
    { id: 'callers_no_calls', title: 'פונים ללא קריאה משויכת', icon: <PhoneOff size={24} />, color: 'rose' }
  ];

  const triggerView = (viewId: string) => {
    setActiveView(null);
    setIsLoading(true);
    setTimeout(() => {
      setActiveView(viewId);
      setIsLoading(false);
    }, 800);
  };

  const renderViewContent = () => {
    switch (activeView) {
      case 'volunteer_activity_view':
        return (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold">
                  <th className="p-4">שם מתנדב</th>
                  <th className="p-4">קריאות שבוצעו</th>
                  <th className="p-4">שעות הכשרה</th>
                  <th className="p-4">סטטוס זמינות</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100">
                  <td className="p-4 font-medium text-slate-800">דני מזרחי</td>
                  <td className="p-4 text-slate-600">45</td>
                  <td className="p-4 text-slate-600">12</td>
                  <td className="p-4"><span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-lg text-xs font-bold">זמין</span></td>
                </tr>
                <tr className="border-b border-slate-100">
                  <td className="p-4 font-medium text-slate-800">ישראל ישראלי</td>
                  <td className="p-4 text-slate-600">112</td>
                  <td className="p-4 text-slate-600">30</td>
                  <td className="p-4"><span className="bg-slate-100 text-slate-700 px-2 py-1 rounded-lg text-xs font-bold">תפוס</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      case 'caller_call_location_view':
        return (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold">
                  <th className="p-4">שם פונה</th>
                  <th className="p-4">טלפון</th>
                  <th className="p-4">סוג קריאה</th>
                  <th className="p-4">סטטוס</th>
                  <th className="p-4">כתובת</th>
                  <th className="p-4">קוארדינטות</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100">
                  <td className="p-4 font-medium text-slate-800">יוסי רובין</td>
                  <td className="p-4 text-slate-600">050-1234567</td>
                  <td className="p-4 text-slate-600">פנצ'ר</td>
                  <td className="p-4 text-blue-600 font-bold">בטיפול</td>
                  <td className="p-4 text-slate-600">דרך נמיר 10, ת"א</td>
                  <td className="p-4 text-slate-400 text-xs">32.08, 34.78</td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      case 'calls_by_urgency':
        return (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold">
                  <th className="p-4">רמת דחיפות</th>
                  <th className="p-4">כמות קריאות</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100">
                  <td className="p-4 font-medium text-red-600">חירום (5)</td>
                  <td className="p-4 text-slate-600">2</td>
                </tr>
                <tr className="border-b border-slate-100">
                  <td className="p-4 font-medium text-orange-600">גבוהה (4)</td>
                  <td className="p-4 text-slate-600">14</td>
                </tr>
                <tr className="border-b border-slate-100">
                  <td className="p-4 font-medium text-slate-800">רגילה (3)</td>
                  <td className="p-4 text-slate-600">45</td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      case 'callers_no_calls':
        return (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold">
                  <th className="p-4">שם פונה</th>
                  <th className="p-4">טלפון</th>
                  <th className="p-4">הערות רשומות</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100">
                  <td className="p-4 font-medium text-slate-800">אבי כהן</td>
                  <td className="p-4 text-slate-600">052-9876543</td>
                  <td className="p-4 text-slate-600">משתמש באפליקציה, טרם פתח קריאה</td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="py-10 max-w-6xl mx-auto space-y-10">
      <div className="flex items-center gap-4">
        <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600">
          <Eye size={32} />
        </div>
        <div>
          <h2 className="text-3xl font-black text-slate-900">תצוגות משולבות (Views)</h2>
          <p className="text-slate-500 font-medium">צפייה בנתונים מקושרים מתוך מסד הנתונים</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {viewsList.map((view) => (
          <motion.button
            key={view.id}
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => triggerView(view.id)}
            className={`bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between group transition-all ${activeView === view.id ? 'ring-2 ring-indigo-500 border-transparent' : 'hover:border-slate-300'}`}
          >
            <div className="flex items-center gap-4 text-right">
              <div className={`p-4 rounded-2xl bg-${view.color}-50 text-${view.color}-600 group-hover:bg-${view.color}-600 group-hover:text-white transition-colors`}>
                {view.icon}
              </div>
              <h3 className="font-bold text-slate-800 group-hover:text-slate-900 transition-colors">
                {view.title}
              </h3>
            </div>
          </motion.button>
        ))}
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden min-h-[400px]">
        {isLoading ? (
          <div className="h-full flex flex-col items-center justify-center py-32 space-y-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-slate-500 font-medium animate-pulse">טוען תצוגה ממסד הנתונים...</p>
          </div>
        ) : activeView ? (
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-6"
            >
              <div className="mb-6">
                <h3 className="text-2xl font-black text-slate-800">
                  {viewsList.find(v => v.id === activeView)?.title}
                </h3>
              </div>
              
              {renderViewContent()}
              
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="h-full flex flex-col items-center justify-center py-32 text-center px-6">
            <div className="bg-slate-50 p-6 rounded-full mb-4">
              <Eye size={48} className="text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-800">בחר תצוגה (View) להצגה</h3>
            <p className="text-slate-500 mt-2 max-w-sm">לחץ על אחת מהתצוגות למעלה כדי לשלוף את הנתונים המקושרים.</p>
          </div>
        )}
      </div>
    </div>
  );
};
