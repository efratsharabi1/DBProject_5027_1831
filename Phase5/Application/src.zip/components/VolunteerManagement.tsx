import React, { useState } from 'react';
import { Volunteer } from '../types';
import { User, Phone, Mail, MapPin, Calendar, Pencil, Star, ShieldAlert, Search, Filter } from 'lucide-react';
import { motion } from 'motion/react';

interface VolunteerManagementProps {
  volunteers: Volunteer[];
  onEdit: (volunteer: Volunteer) => void;
  onPromote: (volunteer: Volunteer) => void;
  onDelete?: (id: string) => void;
  currentRole?: string;
}

export const VolunteerManagement: React.FC<VolunteerManagementProps> = ({ volunteers, onEdit, onPromote, onDelete, currentRole }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterActive, setFilterActive] = useState<'all' | 'active' | 'inactive'>('all');
  const [filterAvailability, setFilterAvailability] = useState<'all' | 'available' | 'busy' | 'offline'>('all');
  const [confirmingDelete, setConfirmingDelete] = useState<string | null>(null);

  const filteredVolunteers = volunteers.filter(v => {
    const matchesSearch = v.name.includes(searchTerm) || 
                          (v.phone_number || '').includes(searchTerm) || 
                          (v.address || '').includes(searchTerm);
    const matchesActive = filterActive === 'all' || 
                          (filterActive === 'active' && v.is_active !== 0) || 
                          (filterActive === 'inactive' && v.is_active === 0);
    const status = v.availability_status || (v.is_busy ? 'busy' : 'available');
    const matchesAvailability = filterAvailability === 'all' || status === filterAvailability;

    return matchesSearch && matchesActive && matchesAvailability;
  });

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="חיפוש לפי שם, טלפון או עיר..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-4 pr-10 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm"
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200 text-sm">
            <Filter size={16} className="text-slate-500" />
            <select 
              value={filterActive} 
              onChange={(e) => setFilterActive(e.target.value as any)}
              className="bg-transparent font-bold text-slate-700 outline-none"
            >
              <option value="all">כל הסטטוסים</option>
              <option value="active">פעילים בלבד</option>
              <option value="inactive">לא פעילים</option>
            </select>
          </div>
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200 text-sm">
            <select 
              value={filterAvailability} 
              onChange={(e) => setFilterAvailability(e.target.value as any)}
              className="bg-transparent font-bold text-slate-700 outline-none"
            >
              <option value="all">זמינות</option>
              <option value="available">פנוי</option>
              <option value="busy">תפוס</option>
              <option value="offline">לא זמין</option>
            </select>
          </div>
        </div>
      </div>

      {filteredVolunteers.length === 0 ? (
        <div className="text-center py-12 text-slate-500 bg-white rounded-2xl border border-slate-200">
          לא נמצאו מתנדבים מתאימים לחיפוש
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVolunteers.map((v) => (
        <motion.div
          key={v.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 hover:shadow-md transition-shadow relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-2 h-full bg-blue-500"></div>
          
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-3">
              <div className="relative">
                <img 
                  src={v.photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(v.name)}&background=random`} 
                  alt={v.name}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-sm"
                  referrerPolicy="no-referrer"
                />
                {v.availability_status === 'busy' || v.is_busy ? (
                  <div className="absolute -bottom-1 -right-1 bg-red-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full border-2 border-white shadow-sm animate-pulse">
                    תפוס
                  </div>
                ) : v.availability_status === 'offline' ? (
                  <div className="absolute -bottom-1 -right-1 bg-slate-400 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full border-2 border-white shadow-sm">
                    לא זמין
                  </div>
                ) : (
                  <div className="absolute -bottom-1 -right-1 bg-green-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full border-2 border-white shadow-sm">
                    פנוי
                  </div>
                )}
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  {v.name}
                  {v.is_active === 0 && (
                     <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">לא פעיל</span>
                  )}
                </h3>
              </div>
            </div>
            <div className="flex gap-1 items-center">
              {onDelete && confirmingDelete === v.id ? (
                <div className="flex bg-red-50 rounded-lg p-1 border border-red-200">
                  <button onClick={() => { onDelete(v.id!); setConfirmingDelete(null); }} className="px-2 font-bold text-red-600 text-sm">מחק!</button>
                  <button onClick={() => setConfirmingDelete(null)} className="px-2 font-bold text-red-400 text-sm">ביטול</button>
                </div>
              ) : (
                <>
                  {(currentRole === 'boss' || currentRole === 'manager') && v.role !== 'manager' && v.role !== 'boss' && (
                    <button
                      onClick={() => onPromote(v)}
                      className="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-all"
                      title="הפוך למנהל"
                    >
                      <ShieldAlert size={18} />
                    </button>
                  )}
                  <button
                    onClick={() => onEdit(v)}
                    className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                    title="ערוך מתנדב"
                  >
                    <Pencil size={18} />
                  </button>
                  {onDelete && (currentRole === 'boss' || currentRole === 'manager') && (
                    <button
                      onClick={() => setConfirmingDelete(v.id!)}
                      className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                      title="מחק מתנדב"
                    >
                      <User size={18} />
                    </button>
                  )}
                </>
              )}
            </div>
          </div>

          <div className="space-y-3 text-sm text-slate-600">
            <div className="flex items-center gap-2">
              <Phone size={16} className="text-slate-400" />
              <span>{v.phone}</span>
            </div>
            {v.email && (
              <div className="flex items-center gap-2">
                <Mail size={16} className="text-slate-400" />
                <span className="truncate">{v.email}</span>
              </div>
            )}
            {v.residence && (
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-slate-400" />
                <span>{v.residence}</span>
              </div>
            )}
            {v.age && (
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-slate-400" />
                <span>גיל: {v.age}</span>
              </div>
            )}
            {v.has_equipment === 1 && (
              <div className="mt-2 text-xs font-bold text-blue-600 bg-blue-50 w-fit px-2 py-1 rounded-lg">
                יש ציוד מיוחד
              </div>
            )}
          </div>
        </motion.div>
      ))}
        </div>
      )}
    </div>
  );
};
