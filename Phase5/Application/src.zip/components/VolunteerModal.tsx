import React, { useState, useEffect } from 'react';
import { X, UserPlus, Save, Trash2, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Volunteer, Skill, Availability } from '../types';

interface VolunteerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<string | null | void> | void;
  initialData?: Volunteer | null;
}

export const VolunteerModal: React.FC<VolunteerModalProps> = ({ isOpen, onClose, onSubmit, initialData }) => {
  const [activeTab, setActiveTab] = useState<'details' | 'skills' | 'availability'>('details');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [volunteerSkills, setVolunteerSkills] = useState<Skill[]>([]);
  const [availabilities, setAvailabilities] = useState<Availability[]>([]);
  const [newAvailability, setNewAvailability] = useState({ day_of_week: 0, start_time: '08:00', end_time: '17:00' });
  const [newSkillId, setNewSkillId] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    first_name: '',
    last_name: '',
    phone: '',
    email: '',
    residence: '',
    birthday: '',
    age: '',
    is_active: 1,
    recruitment_date: new Date().toISOString().split('T')[0],
    availability_status: 'available',
    has_equipment: 0,
    photo_url: ''
  });

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    setActiveTab('details');

    const initializeData = async () => {
      try {
        const skillsRes = await fetch('/api/skills');
        const allSkillsData = await skillsRes.json();
        setAllSkills(allSkillsData);

        if (initialData) {
          setFormData({
            name: initialData.name || '',
            first_name: initialData.first_name || '',
            last_name: initialData.last_name || '',
            phone: initialData.phone || '',
            email: initialData.email || '',
            residence: initialData.residence || '',
            birthday: initialData.birthday || '',
            age: initialData.age?.toString() || '',
            is_active: initialData.is_active ?? 1,
            recruitment_date: initialData.recruitment_date || new Date().toISOString().split('T')[0],
            availability_status: initialData.availability_status || 'available',
            has_equipment: initialData.has_equipment ?? 0,
            photo_url: initialData.photo_url || ''
          });
          const [volSkillsRes, availRes] = await Promise.all([
            fetch(`/api/volunteers/${initialData.id}/skills`),
            fetch(`/api/volunteers/${initialData.id}/availabilities`)
          ]);
          setVolunteerSkills(await volSkillsRes.json());
          setAvailabilities(await availRes.json());
        } else {
          setFormData({ 
            name: '', first_name: '', last_name: '', phone: '', email: '', residence: '', birthday: '', age: '', 
            is_active: 1, recruitment_date: new Date().toISOString().split('T')[0], availability_status: 'available', has_equipment: 0, photo_url: '' 
          });
          setVolunteerSkills([]);
          setAvailabilities([]);
        }
      } catch (err) {
        console.error('Error fetching data for modal', err);
      }
    };
    
    initializeData();
  }, [initialData, isOpen]);

  const handleToggleSkill = (skillId: string, isAdding: boolean) => {
    if (isAdding) {
      const skill = allSkills.find(s => s.id === skillId);
      if (skill) setVolunteerSkills([...volunteerSkills, skill]);
    } else {
      setVolunteerSkills(volunteerSkills.filter(s => s.id !== skillId));
    }
  };

  const handleAddAvailability = () => {
    const newAvail = { id: Math.random().toString(), volunteer_id: initialData?.id || '', ...newAvailability };
    setAvailabilities([...availabilities, newAvail]);
  };

  const handleRemoveAvailability = (availId: string) => {
    setAvailabilities(availabilities.filter(a => a.id !== availId));
  };

  const handleGlobalSubmit = async () => {
    setError(null);
    if (!formData.first_name || !formData.last_name || !formData.phone || !formData.email || !formData.residence) {
      setError('רוב השדות הם חובה!');
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('כתובת אימייל אינה תקינה! (לדוגמה: name@example.com)');
      return;
    }

    const phoneRegex = /^0\d{1,2}-?\d{7}$/;
    if (!phoneRegex.test(formData.phone)) {
      setError('מספר פלאפון אינו תקין! (יש להזין מספר ישראלי חוקי, למשל: 050-1234567)');
      return;
    }

    let ageNum = formData.age ? parseInt(formData.age) : undefined;
    if (formData.birthday) {
      const birthDate = new Date(formData.birthday);
      const ageDifMs = Date.now() - birthDate.getTime();
      const ageDate = new Date(ageDifMs);
      ageNum = Math.abs(ageDate.getUTCFullYear() - 1970);
    }

    if (ageNum && ageNum < 18) {
      setError('אסור להירשם מתחת לגיל 18! ההתנדבות מותרת מגיל 18 ומעלה בלבד.');
      return;
    }
    
    setIsSubmitting(true);
    try {
      const err = await onSubmit({
        ...formData,
        age: ageNum,
        name: `${formData.first_name} ${formData.last_name}`,
        skills: volunteerSkills.map(s => s.id),
        availabilities: availabilities
      });
      if (typeof err === 'string') {
        setError(err);
      }
    } catch (e) {
      setError('שגיאה בלתי צפויה');
    } finally {
      setIsSubmitting(false);
    }
  };

  const daysOfWeek = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl"
        >
          <div className="p-6 border-bottom border-slate-100 flex justify-between items-center bg-slate-50">
            <h2 className="text-xl font-black text-slate-800">
              {initialData ? 'עריכת מתנדב' : 'הוספת מתנדב חדש'}
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
              <X size={24} />
            </button>
          </div>

          <div className="flex border-b border-slate-200 px-6 pt-2 bg-slate-50">
            <button
              onClick={() => setActiveTab('details')}
              className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 ${activeTab === 'details' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
            >
              פרטים אישיים
            </button>
            <button
              onClick={() => setActiveTab('skills')}
              className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 ${activeTab === 'skills' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
            >
              מיומנויות
            </button>
            <button
              onClick={() => setActiveTab('availability')}
              className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 ${activeTab === 'availability' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
            >
              זמינות
            </button>
          </div>

          {activeTab === 'details' && (
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">שם פרטי</label>
                  <input
                  required
                  type="text"
                  value={formData.first_name}
                  onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">שם משפחה</label>
                <input
                  required
                  type="text"
                  value={formData.last_name}
                  onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">טלפון</label>
                <input
                  required
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">תאריך לידה</label>
                <input
                  type="date"
                  value={formData.birthday}
                  onChange={(e) => setFormData({ ...formData, birthday: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">מייל</label>
              <input
                required
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">מקום מגורים</label>
                <input
                  required
                  type="text"
                  value={formData.residence}
                  onChange={(e) => setFormData({ ...formData, residence: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">תאריך גיוס</label>
                <input
                  type="date"
                  value={formData.recruitment_date}
                  onChange={(e) => setFormData({ ...formData, recruitment_date: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">סטטוס זמינות</label>
                <select
                  value={formData.availability_status}
                  onChange={(e) => setFormData({ ...formData, availability_status: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all bg-white"
                >
                  <option value="available">זמין</option>
                  <option value="busy">תפוס</option>
                  <option value="offline">לא זמין</option>
                </select>
              </div>
              <div className="flex items-center gap-2 mt-8">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.is_active === 1}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked ? 1 : 0 })}
                  className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="isActive" className="text-sm font-bold text-slate-700">פעיל</label>
              </div>
              <div className="flex items-center gap-2 mt-8">
                <input
                  type="checkbox"
                  id="hasEquipment"
                  checked={formData.has_equipment === 1}
                  onChange={(e) => setFormData({ ...formData, has_equipment: e.target.checked ? 1 : 0 })}
                  className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="hasEquipment" className="text-sm font-bold text-slate-700">ציוד נדרש</label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">כתובת תמונה (URL)</label>
              <input
                type="url"
                value={formData.photo_url}
                onChange={(e) => setFormData({ ...formData, photo_url: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              />
            </div>

            </div>
          )}

          {activeTab === 'skills' && (
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {allSkills.map(skill => {
                      const hasSkill = volunteerSkills.some(vs => vs.id === skill.id);
                      return (
                        <label 
                          key={skill.id} 
                          className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                            hasSkill 
                              ? 'border-blue-500 bg-blue-50/50' 
                              : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={hasSkill}
                            onChange={(e) => handleToggleSkill(skill.id, e.target.checked)}
                            className="w-5 h-5 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                          />
                          <div>
                            <span className="font-bold text-slate-700 block">{skill.name}</span>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                  {allSkills.length === 0 && (
                    <p className="text-slate-500 text-center py-4 text-sm">לא נמצאו מיומנויות במערכת.</p>
              )}
            </div>
          )}

          {activeTab === 'availability' && (
            <div className="p-6 space-y-6">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-4">
                <h3 className="font-bold text-slate-700 text-sm">הוספת חלון זמינות</h3>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">יום</label>
                    <select
                      value={newAvailability.day_of_week}
                      onChange={(e) => setNewAvailability({ ...newAvailability, day_of_week: parseInt(e.target.value) })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                    >
                      {daysOfWeek.map((day, i) => (
                        <option key={i} value={i}>{day}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">משעה</label>
                    <input
                      type="time"
                      value={newAvailability.start_time}
                      onChange={(e) => setNewAvailability({ ...newAvailability, start_time: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">עד שעה</label>
                    <input
                      type="time"
                      value={newAvailability.end_time}
                      onChange={(e) => setNewAvailability({ ...newAvailability, end_time: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                    />
                  </div>
                </div>
                <button
                  onClick={handleAddAvailability}
                  className="w-full bg-blue-100 hover:bg-blue-200 text-blue-700 font-bold py-2 rounded-xl text-sm transition-colors flex justify-center items-center gap-2"
                >
                  <Plus size={16} /> הוסף זמינות
                </button>
              </div>

              <div className="space-y-2">
                {availabilities.length === 0 ? (
                  <p className="text-slate-500 text-center py-4 text-sm">לא הוגדרו חלונות זמינות.</p>
                ) : (
                  availabilities.map(avail => (
                    <div key={avail.id} className="flex justify-between items-center bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                      <div className="flex items-center gap-3">
                        <div className="bg-emerald-100 text-emerald-700 font-black w-8 h-8 rounded-lg flex items-center justify-center text-sm">
                          {daysOfWeek[avail.day_of_week].charAt(0)}'
                        </div>
                        <div className="text-sm font-bold text-slate-700">
                          {avail.start_time} - {avail.end_time}
                        </div>
                      </div>
                      <button onClick={() => handleRemoveAvailability(avail.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          <div className="p-6 border-t border-slate-100 bg-white">
            {error && (
              <div className="bg-red-50 text-red-600 p-3 rounded-xl text-sm font-bold text-center mb-4">
                {error}
              </div>
            )}
            <button
              onClick={handleGlobalSubmit}
              disabled={isSubmitting}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-200"
            >
              {isSubmitting ? (
                 <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : initialData ? <Save size={20} /> : <UserPlus size={20} />}
              {isSubmitting ? 'שומר...' : initialData ? 'עדכן מתנדב' : 'הוסף מתנדב להמערכת'}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
