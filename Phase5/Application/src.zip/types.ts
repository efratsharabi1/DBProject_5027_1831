export type CallStatus = 'open' | 'in-progress' | 'completed';

export interface Call {
  id: string;
  title: string;
  description: string;
  location: string;
  latitude?: number;
  longitude?: number;
  type: string;
  status: CallStatus;
  created_at: string;
  call_date?: string;
  call_time?: string;
  priority_level?: number;
  image_url?: string;
  caller_id?: string;
  caller_name?: string;
  caller_phone?: string;
  caller_special_features?: string;
  location_id?: string;
  type_id?: string;
  status_id?: string;
  volunteer_id?: string;
  volunteer_name?: string;
}

export interface Volunteer {
  id: string;
  name: string;
  first_name?: string;
  last_name?: string;
  phone: string;
  email?: string;
  residence?: string;
  birthday?: string;
  age?: number;
  photo_url?: string;
  points: number;
  is_busy?: number;
  role?: 'boss' | 'manager' | 'volunteer';
  is_active?: number;
  recruitment_date?: string;
  availability_status?: string;
  has_equipment?: number;
}

export interface User {
  id: string;
  email: string;
  role: 'boss' | 'manager' | 'volunteer';
  volunteer_id: string;
}

export interface Skill {
  id: string;
  name: string;
  description?: string;
  difficulty_level?: number;
  requires_certificate?: number;
  category_id?: string;
}

export interface Availability {
  id: string;
  volunteer_id: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  preferred_region?: string;
}

export interface Caller {
  id: string;
  name: string;
  phone_number: string;
  special_features?: string;
}

export interface LocationInfo {
  id: string;
  address: string;
  latitude?: number;
  longitude?: number;
  location_notes?: string;
}

export interface Category {
  id: string;
  name: string;
}

export interface Training {
  id: string;
  name: string;
  description?: string;
  max_participant?: number;
  duration_hours?: number;
}

export interface Scheduled {
  id: string;
  training_id: string;
  meeting_date: string;
  start_time: string;
  end_time: string;
  location_scheduled?: string;
}
